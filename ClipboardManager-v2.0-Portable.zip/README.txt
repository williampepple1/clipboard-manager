Clipboard History Manager v1.0
==============================

A lightweight clipboard history manager that stores up to 50 items.

HOW TO USE:
-----------
1. Run clipboard-manager.exe
2. The app will monitor your clipboard automatically
3. Every time you copy something, it gets added to the history
4. Double-click any item to copy it back to your clipboard
5. Close the window - it minimizes to the system tray
6. Double-click the tray icon to restore the window
7. Right-click the tray icon for options

FEATURES:
---------
- Stores up to 50 clipboard items (text and images)
- Stack behavior: newest items appear at the top
- When limit is reached, oldest item is automatically removed
- Duplicate prevention (won't add same content twice in a row)
- System tray integration - keeps running in background
- Timestamp for each copied item

BUTTONS:
--------
- Copy: Copy selected item to clipboard
- Delete: Remove selected item from history
- Clear All: Remove all items from history

DISTRIBUTION:
-------------
This is a standalone Windows application. No installation required.
Just copy this entire folder anywhere and run clipboard-manager.exe.
